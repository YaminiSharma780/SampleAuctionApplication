//DBConnection.java
package com.mvc.util;
import java.sql.*;

public class DBConnection {
public static Connection createConnection()
{
	Connection con = null;
	try 
	{
			try 
			{
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/yamini","root", "12345");			}
			catch (ClassNotFoundException e)
			{
				e.printStackTrace();
			}	
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	}
return con; 
}
}